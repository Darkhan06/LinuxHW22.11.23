import type.GameVars;

import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
//         1 уровень сложности: Задание 1.
//        Пользователь вводит, сколько лет он состоит в браке. Программа должна вывести,
//         какая годовщина свадьбы будет у пользователя следующей (бумажная, ситцевая, чугунная, серебряная и.д.).
//         Не обязательно указывать все годовщины, достаточно 10-15.
//         Узнать про годовщины можно, например,
//         здесь https://instalook.ru/blog/nazvaniya-vseh-godovschin-svadeb-do-100-let
        System.out.println("Введите сколько лет вы в браке");
        Scanner sc = new Scanner(System.in);
        int yearWeddings = sc.nextInt();
        String yearName = switch (yearWeddings) {
            case 1 -> "Chintz wedding";
            case 2 -> "Paper wedding";
            case 3 -> "Leather wedding";
            case 4 -> "Linen wedding";
            case 5 -> "Wooden wedding";
            case 6 -> "Cast Iron Wedding";
            case 7 -> "Copper wedding";
            case 8 -> "Tin wedding";
            case 9 -> "Earthenware wedding";
            case 10 -> "Pewter wedding";
            default -> "Unknown";
        };
        System.out.println(yearName);
        System.out.println("--------------------------------");

        System.out.println(Arrays.toString(GameVars.values()));
        System.out.println("Напишите ваш выбор");
        String playerText = new Scanner(System.in).nextLine();
        GameVars playerChoice = GameVars.valueOf(playerText.trim().toUpperCase());

        int compNum = new Random().nextInt(0, 3);
        GameVars compChoice = switch (compNum) {
            case 0 -> GameVars.STONE;
            case 1 -> GameVars.SCISSORS;
            case 2 -> GameVars.PAPER;
            default -> throw new IllegalStateException("Unexpected value: " + compNum);
        };

        System.out.println(compChoice);

        if (playerChoice == compChoice) {
            System.out.println("Ничья (я не знаю как на англ <Ничья>, draw,tie?)");
        } else {
            if ((compChoice == GameVars.STONE && playerChoice == GameVars.PAPER) ||
                    (compChoice == GameVars.PAPER && playerChoice == GameVars.SCISSORS) ||
                    (compChoice == GameVars.SCISSORS && playerChoice == GameVars.STONE)) {
                System.out.println("You win!");
            } else {
                System.out.println("You  lose!");
            }
        }
    }
}



