package type;

public enum GameVars {
    STONE,
    SCISSORS,
    PAPER
}
